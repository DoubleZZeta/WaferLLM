Snapshot of all CSV, JSON and execution logs under the active WaferLLM runtime runs directory.
Includes the full profiled dense/low-rank sweep, smoke test, and earlier FFN grid comparison.
The benchmark is still running: unfinished cases have no final result or phase CSV yet.
Each file was copied individually while the benchmark continued.

Main results: runs/profile_full_dense64_20261003/dense.csv and runs/profile_full_rect_20261003/fused-rectangular.csv.
Detailed profiling: each run's logs/*.phases.csv (phase, mean_cycles, max_pe_cycles).
Execution logs and JSON phase data are included alongside the CSVs.
manifest.json records the size and SHA-256 of every archived source file.
